+++
title = "Content tagged as 'Academic'"
date = "2017-01-01T00:00:00"
math = false
highlight = false

# Optional featured image (relative to `static/img/` folder).
[header]
image = "headers/bubbles-wide.jpg"
caption = ""

+++

Here is a list of all the content that has been tagged as *academic*.
