+++
# Recent and Upcoming Talks widget.

date = "2016-04-20T00:00:00"
draft = false

title = "Recent & Upcoming Talks"
subtitle = ""
widget = "talks"

# Order that this section will appear in.
weight = 30

# Number of talks to list.
count = 10

# Show talk details (such as abstract)? (true/false)
detailed_list = false

+++

